onmessage = function(e) {
    onmessage = new Function("e", e.data);
};