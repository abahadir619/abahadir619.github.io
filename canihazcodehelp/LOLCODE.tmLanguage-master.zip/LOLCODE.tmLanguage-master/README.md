LOLCODE.tmLanguage
==================

LOLCODE Syntax Highlighting for Sublime Text 2 and TextMate

Installation
============

1. Download and install LOLCODE.tmlanguage. (See installation instructions for [Sublime package files](http://sublimetext.info/docs/en/extensibility/packages.html#installation-of-packages).)
2. Open your first .lol file and select View | Syntax | LOLCODE.
3. The provided sublime build uses [lci](http://lolcode.org/).  Pull requests are welcome for alternate build systems.
